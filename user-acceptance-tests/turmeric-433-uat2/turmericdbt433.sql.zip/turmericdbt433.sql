-- phpMyAdmin SQL Dump
-- version 3.3.7deb3build0.10.10.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 13, 2011 at 02:42 PM
-- Server version: 5.1.49
-- PHP Version: 5.3.3-1ubuntu9.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `turmericdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `AuditHistory`
--

CREATE TABLE IF NOT EXISTS `AuditHistory` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createdBy` varchar(255) DEFAULT NULL,
  `createdOn` datetime DEFAULT NULL,
  `updatedBy` varchar(255) DEFAULT NULL,
  `updatedOn` datetime DEFAULT NULL,
  `category` varchar(255) DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `entityId` bigint(20) NOT NULL,
  `entityName` varchar(255) DEFAULT NULL,
  `entityType` varchar(255) DEFAULT NULL,
  `operationType` varchar(255) DEFAULT NULL,
  `subjectId` bigint(20) NOT NULL,
  `subjectName` varchar(255) DEFAULT NULL,
  `subjectType` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=115 ;

--
-- Dumping data for table `AuditHistory`
--

INSERT INTO `AuditHistory` (`id`, `createdBy`, `createdOn`, `updatedBy`, `updatedOn`, `category`, `comment`, `entityId`, `entityName`, `entityType`, `operationType`, `subjectId`, `subjectName`, `subjectType`) VALUES
(111, NULL, '2011-01-03 13:50:44', NULL, NULL, 'SUBJECTGROUP', 'SUBJECTGROUP[USER:sg2:25] create @[USER:admin:1]', 25, 'sg2', 'USER', 'create', 1, 'admin', 'USER'),
(112, NULL, '2011-01-03 13:51:33', NULL, NULL, 'POLICY', 'POLICY[BLACKLIST:policydelete:69] create @[USER:admin:1]', 69, 'policydelete', 'BLACKLIST', 'create', 1, 'admin', 'USER'),
(113, NULL, '2011-01-03 13:53:09', NULL, NULL, 'POLICY', 'POLICY[BLACKLIST:policydelete:69] delete @[USER:admin:1]', 69, 'policydelete', 'BLACKLIST', 'delete', 1, 'admin', 'USER'),
(114, NULL, '2011-01-03 13:53:16', NULL, NULL, 'POLICY', 'POLICY[BLACKLIST:dadadad:7] delete @[USER:admin:1]', 7, 'dadadad', 'BLACKLIST', 'delete', 1, 'admin', 'USER');

-- --------------------------------------------------------

--
-- Table structure for table `BasicAuth`
--

CREATE TABLE IF NOT EXISTS `BasicAuth` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createdBy` varchar(255) DEFAULT NULL,
  `createdOn` datetime DEFAULT NULL,
  `updatedBy` varchar(255) DEFAULT NULL,
  `updatedOn` datetime DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `subjectName` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `BasicAuth`
--

INSERT INTO `BasicAuth` (`id`, `createdBy`, `createdOn`, `updatedBy`, `updatedOn`, `password`, `subjectName`) VALUES
(1, 'jose', '2010-12-22 14:13:54', NULL, NULL, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `ConditionTbl`
--

CREATE TABLE IF NOT EXISTS `ConditionTbl` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createdBy` varchar(255) DEFAULT NULL,
  `createdOn` datetime DEFAULT NULL,
  `updatedBy` varchar(255) DEFAULT NULL,
  `updatedOn` datetime DEFAULT NULL,
  `expression_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKC21C54C3643700EB` (`expression_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `ConditionTbl`
--

INSERT INTO `ConditionTbl` (`id`, `createdBy`, `createdOn`, `updatedBy`, `updatedOn`, `expression_id`) VALUES
(1, NULL, NULL, NULL, NULL, 1),
(2, NULL, NULL, NULL, NULL, 2);

-- --------------------------------------------------------

--
-- Table structure for table `Operation`
--

CREATE TABLE IF NOT EXISTS `Operation` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createdBy` varchar(255) DEFAULT NULL,
  `createdOn` datetime DEFAULT NULL,
  `updatedBy` varchar(255) DEFAULT NULL,
  `updatedOn` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `operationName` varchar(255) DEFAULT NULL,
  `resource_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKDA8CF547555CDD6B` (`resource_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=108 ;

--
-- Dumping data for table `Operation`
--

INSERT INTO `Operation` (`id`, `createdBy`, `createdOn`, `updatedBy`, `updatedOn`, `description`, `operationName`, `resource_id`) VALUES
(1, NULL, '2010-12-14 10:49:55', NULL, NULL, NULL, 'checkout', 1),
(2, NULL, '2010-12-14 10:49:55', NULL, NULL, NULL, 'commit', 2),
(3, NULL, '2010-12-14 10:49:55', NULL, NULL, NULL, 'merge', 1),
(4, NULL, '2010-12-14 10:49:55', NULL, NULL, NULL, 'createPolicy', 3),
(5, NULL, '2010-12-14 10:49:55', NULL, NULL, NULL, 'getMetaData', 3),
(6, NULL, '2010-12-14 10:49:55', NULL, NULL, NULL, 'findPolicies', 3),
(90, 'admin', '2011-01-03 13:50:44', NULL, NULL, NULL, '25', 9),
(91, 'admin', '2011-01-03 13:50:44', NULL, NULL, NULL, 'Admin_SubjectGroup_sg2', 8),
(92, 'admin', '2011-01-03 13:50:44', NULL, NULL, NULL, 'sg2', 8),
(93, 'admin', '2011-01-03 13:50:44', NULL, NULL, NULL, '25', 8),
(94, 'admin', '2011-01-03 13:50:44', NULL, NULL, NULL, '26', 8),
(95, 'admin', '2011-01-03 13:51:33', NULL, NULL, NULL, '69', 4),
(96, 'admin', '2011-01-03 13:51:33', NULL, NULL, NULL, 'policydelete', 4),
(97, 'admin', '2011-01-03 13:51:33', NULL, NULL, NULL, '69', 5),
(98, 'admin', '2011-01-03 13:51:33', NULL, NULL, NULL, 'policydelete', 5),
(99, 'admin', '2011-01-03 13:51:33', NULL, NULL, NULL, '69', 6),
(100, 'admin', '2011-01-03 13:51:33', NULL, NULL, NULL, 'policydelete', 6),
(101, 'admin', '2011-01-03 13:51:33', NULL, NULL, NULL, '69', 7),
(102, 'admin', '2011-01-03 13:51:33', NULL, NULL, NULL, 'policydelete', 7),
(103, 'admin', '2011-01-03 13:51:33', NULL, NULL, NULL, 'Admin_Policy_policydelete', 8),
(104, 'admin', '2011-01-03 13:51:33', NULL, NULL, NULL, '28', 8),
(7, NULL, '2010-12-14 10:49:55', NULL, NULL, NULL, 'findSubjectGroups', 3),
(8, NULL, '2010-12-14 10:49:55', NULL, NULL, NULL, 'findSubjects', 3),
(9, NULL, '2010-12-14 10:49:55', NULL, NULL, NULL, 'findResources', 3),
(10, NULL, '2010-12-14 10:49:55', NULL, NULL, NULL, 'createSubjectGroups', 3),
(89, 'admin', '2011-01-03 13:50:44', NULL, NULL, NULL, 'sg2', 9),
(13, NULL, '2010-12-14 10:49:55', NULL, NULL, NULL, 'getResources', 3),
(14, NULL, '2010-12-14 10:49:55', NULL, NULL, NULL, 'getEntityHistory', 3),
(11, NULL, '2010-12-14 10:49:55', NULL, NULL, NULL, 'updateSubjectGroups', 3),
(12, NULL, '2010-12-14 10:49:55', NULL, NULL, NULL, 'deletePolicy', 3),
(105, NULL, NULL, NULL, NULL, 'Get Version for the service', 'getVersion', 10),
(106, NULL, NULL, NULL, NULL, 'Send a message', 'sendMessage', 10),
(107, NULL, NULL, NULL, NULL, 'Get a message', 'getMessages', 10);

-- --------------------------------------------------------

--
-- Table structure for table `Policy`
--

CREATE TABLE IF NOT EXISTS `Policy` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createdBy` varchar(255) DEFAULT NULL,
  `createdOn` datetime DEFAULT NULL,
  `updatedBy` varchar(255) DEFAULT NULL,
  `updatedOn` datetime DEFAULT NULL,
  `active` bit(1) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `policyName` varchar(255) DEFAULT NULL,
  `policyType` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=72 ;

--
-- Dumping data for table `Policy`
--

INSERT INTO `Policy` (`id`, `createdBy`, `createdOn`, `updatedBy`, `updatedOn`, `active`, `description`, `policyName`, `policyType`) VALUES
(1, NULL, '2010-12-14 10:12:58', NULL, '2010-12-20 15:02:32', b'1', 'der', 'FooBar9', 'BLACKLIST'),
(2, NULL, '2010-12-14 10:29:01', NULL, '2010-12-22 10:31:29', b'0', NULL, 'BL', 'BLACKLIST'),
(3, NULL, '2010-12-14 16:39:04', NULL, '2010-12-23 16:35:55', b'1', '', 'BL1', 'BLACKLIST'),
(4, NULL, '2010-12-14 16:39:04', NULL, NULL, b'1', NULL, 'RL1', 'RL'),
(5, NULL, '2010-12-14 16:39:04', NULL, NULL, b'1', NULL, 'RL2', 'RL'),
(6, NULL, '2010-12-14 16:39:04', NULL, NULL, b'1', NULL, 'whitelist1', 'WHITELIST'),
(8, NULL, '2010-12-23 15:25:07', NULL, NULL, b'1', 'an auth policy', 'PolicyService', 'AUTHZ'),
(68, 'admin', '2011-01-03 13:51:28', NULL, NULL, b'0', NULL, 'policy to delete', 'BLACKLIST'),
(67, 'admin', '2011-01-03 13:50:44', NULL, '2011-01-03 13:50:44', b'1', 'Managing SubjectGroup sg2', 'Admin_SubjectGroup_sg2', 'AUTHZ'),
(71, 'admin', '2011-01-13 11:57:55', NULL, NULL, b'1', 'Example AUTHZ policy', 'Uat2MessageService', 'AUTHZ');

-- --------------------------------------------------------

--
-- Table structure for table `Policy_ExclusionSubjectGroups`
--

CREATE TABLE IF NOT EXISTS `Policy_ExclusionSubjectGroups` (
  `Policy_id` bigint(20) NOT NULL,
  `exclusionSubjectGroups_id` bigint(20) NOT NULL,
  KEY `FK45E0F89F741F702C` (`exclusionSubjectGroups_id`),
  KEY `FK45E0F89FD5D8832B` (`Policy_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Policy_ExclusionSubjectGroups`
--


-- --------------------------------------------------------

--
-- Table structure for table `Policy_ExclusionSubjects`
--

CREATE TABLE IF NOT EXISTS `Policy_ExclusionSubjects` (
  `Policy_id` bigint(20) NOT NULL,
  `exclusionSubjects_id` bigint(20) NOT NULL,
  KEY `FKC8318EE8B3D781A0` (`exclusionSubjects_id`),
  KEY `FKC8318EE8D5D8832B` (`Policy_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Policy_ExclusionSubjects`
--


-- --------------------------------------------------------

--
-- Table structure for table `Policy_Operation`
--

CREATE TABLE IF NOT EXISTS `Policy_Operation` (
  `Policy_id` bigint(20) NOT NULL,
  `operations_id` bigint(20) NOT NULL,
  KEY `FK6CA0829A4BFA9764` (`operations_id`),
  KEY `FK6CA0829AD5D8832B` (`Policy_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Policy_Operation`
--

INSERT INTO `Policy_Operation` (`Policy_id`, `operations_id`) VALUES
(1, 1),
(5, 2),
(8, 12),
(8, 11),
(8, 10),
(8, 14),
(68, 12),
(67, 90),
(8, 9),
(8, 8),
(8, 7),
(8, 6),
(67, 91),
(67, 89),
(67, 94),
(67, 92),
(67, 93),
(8, 13),
(8, 5),
(8, 4),
(71, 106),
(71, 107),
(71, 105);

-- --------------------------------------------------------

--
-- Table structure for table `Policy_Resource`
--

CREATE TABLE IF NOT EXISTS `Policy_Resource` (
  `Policy_id` bigint(20) NOT NULL,
  `resources_id` bigint(20) NOT NULL,
  KEY `FKCAF2247BF4EC17F4` (`resources_id`),
  KEY `FKCAF2247BD5D8832B` (`Policy_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Policy_Resource`
--

INSERT INTO `Policy_Resource` (`Policy_id`, `resources_id`) VALUES
(1, 1),
(5, 2),
(8, 3);

-- --------------------------------------------------------

--
-- Table structure for table `Policy_Rule`
--

CREATE TABLE IF NOT EXISTS `Policy_Rule` (
  `Policy_id` bigint(20) NOT NULL,
  `rules_id` bigint(20) NOT NULL,
  KEY `FKE46F35E941837750` (`rules_id`),
  KEY `FKE46F35E9D5D8832B` (`Policy_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Policy_Rule`
--

INSERT INTO `Policy_Rule` (`Policy_id`, `rules_id`) VALUES
(1, 1),
(4, 1),
(5, 1),
(5, 2),
(6, 1);

-- --------------------------------------------------------

--
-- Table structure for table `Policy_Subject`
--

CREATE TABLE IF NOT EXISTS `Policy_Subject` (
  `Policy_id` bigint(20) NOT NULL,
  `subjects_id` bigint(20) NOT NULL,
  KEY `FK5E0FB31FAB44C2E` (`subjects_id`),
  KEY `FK5E0FB31FD5D8832B` (`Policy_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Policy_Subject`
--

INSERT INTO `Policy_Subject` (`Policy_id`, `subjects_id`) VALUES
(1, 1),
(6, 2),
(4, 3),
(5, 5),
(6, 5),
(6, 4),
(3, 3),
(8, 1),
(71, 1);

-- --------------------------------------------------------

--
-- Table structure for table `Policy_SubjectGroup`
--

CREATE TABLE IF NOT EXISTS `Policy_SubjectGroup` (
  `Policy_id` bigint(20) NOT NULL,
  `subjectGroups_id` bigint(20) NOT NULL,
  KEY `FKBFCC6EA0AC010E5E` (`subjectGroups_id`),
  KEY `FKBFCC6EA0D5D8832B` (`Policy_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Policy_SubjectGroup`
--

INSERT INTO `Policy_SubjectGroup` (`Policy_id`, `subjectGroups_id`) VALUES
(67, 26);

-- --------------------------------------------------------

--
-- Table structure for table `PrimitiveValue`
--

CREATE TABLE IF NOT EXISTS `PrimitiveValue` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createdBy` varchar(255) DEFAULT NULL,
  `createdOn` datetime DEFAULT NULL,
  `updatedBy` varchar(255) DEFAULT NULL,
  `updatedOn` datetime DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `PrimitiveValue`
--

INSERT INTO `PrimitiveValue` (`id`, `createdBy`, `createdOn`, `updatedBy`, `updatedOn`, `type`, `value`) VALUES
(1, NULL, NULL, NULL, NULL, 0, 'HITS>5'),
(2, NULL, NULL, NULL, NULL, 0, 'PaymentService.commit:count>3');

-- --------------------------------------------------------

--
-- Table structure for table `Resource`
--

CREATE TABLE IF NOT EXISTS `Resource` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createdBy` varchar(255) DEFAULT NULL,
  `createdOn` datetime DEFAULT NULL,
  `updatedBy` varchar(255) DEFAULT NULL,
  `updatedOn` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `resourceName` varchar(255) DEFAULT NULL,
  `resourceType` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `Resource`
--

INSERT INTO `Resource` (`id`, `createdBy`, `createdOn`, `updatedBy`, `updatedOn`, `description`, `resourceName`, `resourceType`) VALUES
(1, NULL, '2010-12-14 10:49:55', NULL, NULL, 'test', 'testService', 'SERVICE'),
(2, NULL, '2010-12-14 11:08:27', NULL, NULL, 'desc Payment', 'PaymentService', 'SERVICE'),
(3, NULL, '2010-12-14 10:49:55', NULL, NULL, NULL, 'PolicyService', 'SERVICE'),
(4, 'admin', '2010-12-29 17:38:46', NULL, NULL, NULL, 'SERVICE.PolicyService.disablePolicy', 'OBJECT'),
(5, 'admin', '2010-12-29 17:38:46', NULL, NULL, NULL, 'SERVICE.PolicyService.deletePolicy', 'OBJECT'),
(6, 'admin', '2010-12-29 17:38:46', NULL, NULL, NULL, 'SERVICE.PolicyService.enablePolicy', 'OBJECT'),
(7, 'admin', '2010-12-29 17:38:46', NULL, NULL, NULL, 'SERVICE.PolicyService.updatePolicy', 'OBJECT'),
(8, 'admin', '2010-12-29 17:38:46', NULL, NULL, NULL, 'SERVICE.PolicyService.updateSubjectGroups', 'OBJECT'),
(9, 'admin', '2011-01-02 18:03:17', NULL, NULL, NULL, 'SERVICE.PolicyService.deleteSubjectGroups', 'OBJECT'),
(10, NULL, NULL, NULL, NULL, NULL, 'Uat2MessageServiceV1', 'SERVICE');

-- --------------------------------------------------------

--
-- Table structure for table `Resource_Operation`
--

CREATE TABLE IF NOT EXISTS `Resource_Operation` (
  `Resource_id` bigint(20) NOT NULL,
  `operations_id` bigint(20) NOT NULL,
  PRIMARY KEY (`Resource_id`,`operations_id`),
  UNIQUE KEY `operations_id` (`operations_id`),
  KEY `FKBEDA36764BFA9764` (`operations_id`),
  KEY `FKBEDA3676555CDD6B` (`Resource_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Resource_Operation`
--

INSERT INTO `Resource_Operation` (`Resource_id`, `operations_id`) VALUES
(3, 3),
(3, 4),
(3, 13),
(3, 14),
(4, 5),
(4, 6),
(4, 15),
(4, 16),
(5, 7),
(5, 8),
(5, 17),
(5, 18),
(6, 9),
(6, 10),
(6, 19),
(6, 20),
(7, 11),
(7, 12),
(7, 21),
(7, 22),
(10, 105),
(10, 106),
(10, 107);

-- --------------------------------------------------------

--
-- Table structure for table `Rule`
--

CREATE TABLE IF NOT EXISTS `Rule` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createdBy` varchar(255) DEFAULT NULL,
  `createdOn` datetime DEFAULT NULL,
  `updatedBy` varchar(255) DEFAULT NULL,
  `updatedOn` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `effect` int(11) DEFAULT NULL,
  `effectDuration` bigint(20) DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  `rolloverPeriod` bigint(20) DEFAULT NULL,
  `ruleName` varchar(255) DEFAULT NULL,
  `condition_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK270B1C6850D789` (`condition_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `Rule`
--

INSERT INTO `Rule` (`id`, `createdBy`, `createdOn`, `updatedBy`, `updatedOn`, `description`, `effect`, `effectDuration`, `priority`, `rolloverPeriod`, `ruleName`, `condition_id`) VALUES
(1, NULL, NULL, NULL, NULL, 'HITS TEST', 1, 10000, 3, 30000, 'rul1', 1),
(2, NULL, NULL, NULL, NULL, 'ServiceXXX.OperationXX.count test', 3, 10000, NULL, 30000, 'server', 2);

-- --------------------------------------------------------

--
-- Table structure for table `Subject`
--

CREATE TABLE IF NOT EXISTS `Subject` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createdBy` varchar(255) DEFAULT NULL,
  `createdOn` datetime DEFAULT NULL,
  `updatedBy` varchar(255) DEFAULT NULL,
  `updatedOn` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `emailContact` varchar(255) DEFAULT NULL,
  `externalSubjectId` bigint(20) NOT NULL,
  `ipMask` varchar(255) DEFAULT NULL,
  `subjectName` varchar(255) DEFAULT NULL,
  `subjectType` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `Subject`
--

INSERT INTO `Subject` (`id`, `createdBy`, `createdOn`, `updatedBy`, `updatedOn`, `description`, `emailContact`, `externalSubjectId`, `ipMask`, `subjectName`, `subjectType`) VALUES
(1, NULL, '2010-12-14 10:37:42', NULL, NULL, 'IPDESK', NULL, 0, NULL, 'admin', 'USER'),
(2, NULL, '2010-12-14 10:37:42', NULL, NULL, 'IPDESK', NULL, 0, NULL, '1.102.96.107', 'IP'),
(3, NULL, '2010-12-14 10:37:42', NULL, NULL, 'IPDESK', NULL, 0, NULL, '1.102.96.103', 'IP'),
(4, NULL, '2010-12-14 10:37:42', NULL, NULL, 'IPDESK', NULL, 0, NULL, '1.102.96.104', 'IP'),
(5, NULL, '2010-12-14 10:37:42', NULL, NULL, 'IPDESK', NULL, 0, NULL, '1.102.96.105', 'IP'),
(6, NULL, '2010-12-14 10:37:42', NULL, NULL, 'IPDESK', NULL, 0, NULL, '1.102.96.106', 'IP');

-- --------------------------------------------------------

--
-- Table structure for table `SubjectGroup`
--

CREATE TABLE IF NOT EXISTS `SubjectGroup` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createdBy` varchar(255) DEFAULT NULL,
  `createdOn` datetime DEFAULT NULL,
  `updatedBy` varchar(255) DEFAULT NULL,
  `updatedOn` datetime DEFAULT NULL,
  `applyToAll` bit(1) NOT NULL,
  `applyToEach` bit(1) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `subjectGroupCalculator` varchar(255) DEFAULT NULL,
  `subjectGroupName` varchar(255) DEFAULT NULL,
  `subjectType` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=30 ;

--
-- Dumping data for table `SubjectGroup`
--

INSERT INTO `SubjectGroup` (`id`, `createdBy`, `createdOn`, `updatedBy`, `updatedOn`, `applyToAll`, `applyToEach`, `description`, `subjectGroupCalculator`, `subjectGroupName`, `subjectType`) VALUES
(23, 'admin', '2011-01-02 18:03:17', NULL, NULL, b'0', b'0', 'first sg', NULL, 'SG_1', 'IP'),
(24, 'admin', '2011-01-02 18:03:17', NULL, NULL, b'0', b'0', 'Managing Admin_SubjectGroup_SG_1', NULL, 'Admin_SubjectGroup_SG_1', 'USER'),
(25, 'admin', '2011-01-03 13:50:44', NULL, NULL, b'0', b'0', 'subj group 2', NULL, 'sg2', 'USER'),
(26, 'admin', '2011-01-03 13:50:44', NULL, NULL, b'0', b'0', 'Managing Admin_SubjectGroup_sg2', NULL, 'Admin_SubjectGroup_sg2', 'USER'),
(27, 'admin', '2011-01-03 13:51:28', NULL, NULL, b'0', b'0', 'Managing Admin_Policy_policy to delete', NULL, 'Admin_Policy_policy to delete', 'USER'),
(29, 'admin', '2011-01-13 11:57:55', NULL, NULL, b'0', b'0', 'Managing Admin_Policy_Uat2MessageService', NULL, 'Admin_Policy_Uat2MessageService', 'USER');

-- --------------------------------------------------------

--
-- Table structure for table `SubjectGroup_Subject`
--

CREATE TABLE IF NOT EXISTS `SubjectGroup_Subject` (
  `SubjectGroup_id` bigint(20) NOT NULL,
  `subjects_id` bigint(20) NOT NULL,
  KEY `FKFBFB71A0AB44C2E` (`subjects_id`),
  KEY `FKFBFB71A0B009DAAB` (`SubjectGroup_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `SubjectGroup_Subject`
--

INSERT INTO `SubjectGroup_Subject` (`SubjectGroup_id`, `subjects_id`) VALUES
(12, 2),
(12, 3),
(13, 3),
(12, 1),
(11, 5),
(12, 4),
(12, 5),
(12, 6),
(14, 5),
(15, 1),
(16, 1),
(17, 1),
(18, 1),
(19, 1),
(20, 1),
(21, 1),
(22, 1),
(23, 3),
(24, 1),
(25, 1),
(26, 1),
(27, 1),
(29, 1);

-- --------------------------------------------------------

--
-- Table structure for table `SubjectType`
--

CREATE TABLE IF NOT EXISTS `SubjectType` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createdBy` varchar(255) DEFAULT NULL,
  `createdOn` datetime DEFAULT NULL,
  `updatedBy` varchar(255) DEFAULT NULL,
  `updatedOn` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `external` bit(1) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `SubjectType`
--

